@extends('layout.main')

@section('main_content')

	@include('users.user_layout_content')

@stop
